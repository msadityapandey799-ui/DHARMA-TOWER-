# Dharma Tower Website

Static website (sirf `index.html`). GitHub Pages par free host hoti hai.

## Preview (apne computer par)
`index.html` ko double-click karke browser mein kholein. Koi install nahi chahiye.

## GitHub par publish karna
1. github.com par naya **Public** repository banayein (jaise `dharma-tower`).
2. **Add file > Upload files** se `index.html` upload karein, **Commit changes** dabayein.
3. **Settings > Pages**: Source "Deploy from a branch", Branch `main`, folder `/(root)`, **Save**.
4. 1-2 minute baad: `https://AAPKA-USERNAME.github.io/dharma-tower/`

## Rooms, rent aur photos badalna
`index.html` mein GitHub ke pencil icon se `ROOMS` list kholein. Har room ka `rent`, `name` aur `pts` wahin hai.
Room photos `images/` folder mein hain (`room-1.jpg` se `room-4.jpg`). Naya photo badalne ke liye usi naam se `images` folder mein upload karein, ya `photo:"images/naam.jpg"` badlein. Hero image abhi demo illustration hai.

## Enquiry form ko sach mein kaam karwana
Jab tak `CONFIG.endpoint` khaali hai, form kuch nahi bhejta. Wo saaf likhta hai "Not sent" aur email ya call ka option deta hai.
1. formspree.io par free account banayein, **New form** banayein.
2. Mila hua link (`https://formspree.io/f/xxxx`) `CONFIG.endpoint` mein daalein.
3. Ab har request aapke email par aayegi. "Request received" tabhi dikhta hai jab server ne request save ki ho.
Booking tab hi confirm maani jaye jab management phone/email par confirm kare.

## Dhyan rakhein
- Repository public hai, isliye password ya secret key kabhi na daalein.
- Security deposit ya extra charges website par nahi likhe hain. Jab property manager confirm kare tab hi add karein.

## Gallery
`index.html` mein `GALLERY` list hai (photos `images/gallery-1.jpg` se `gallery-10.jpg`). Photo badalne ke liye `images` folder mein usi naam se nayi photo upload karein, ya list mein nayi line jodein: `{l:"Caption",h:600,src:"images/naam.jpg"}` (h = photo ki height, width 800 maankar).
